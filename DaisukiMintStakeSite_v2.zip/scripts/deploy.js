const hre = require('hardhat');

async function main() {
  const NFT = process.env.NFT_ADDRESS || '';
  if (!NFT) throw new Error('Set NFT_ADDRESS in env');
  const rewardRate = process.env.REWARD_RATE_WEI || '1000000000000000'; // example: 0.001 MATIC per second in wei
  const Staking = await hre.ethers.getContractFactory('SimpleStaking');
  const st = await Staking.deploy(NFT, rewardRate);
  await st.deployed();
  console.log('Staking deployed to:', st.address);
}

main().catch(e => { console.error(e); process.exit(1) });
