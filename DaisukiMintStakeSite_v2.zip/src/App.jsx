import React, { useEffect, useState } from 'react'
import { ethers } from 'ethers'

// CONFIG - update STAKING_CONTRACT_ADDRESS after you deploy staking contract (or use the provided deploy script)
const CONFIG = {
  NETWORK_NAME: 'Polygon (Mumbai for test / Polygon mainnet)',
  CHAIN_ID: 137,
  NFT_CONTRACT_ADDRESS: '0x5676fCF549f434D0D1E71baD9370cdb451968109',
  STAKING_CONTRACT_ADDRESS: '0xREPLACE_WITH_STAKING_CONTRACT_ADDRESS',
  NFT_ABI: [
    'function ownerOf(uint256 tokenId) view returns (address)',
    'function tokenURI(uint256 tokenId) view returns (string)',
    'function isApprovedForAll(address owner, address operator) view returns (bool)',
    'function setApprovalForAll(address operator, bool approved)'
  ],
  STAKING_ABI: [
    'function stake(uint256 tokenId)',
    'function unstake(uint256 tokenId)',
    'function claimRewards()',
    'function stakedOf(address owner) view returns (uint256[])',
    'event Staked(address indexed owner, uint256 indexed tokenId)',
    'event Unstaked(address indexed owner, uint256 indexed tokenId)'
  ]
}

function formatAddr(a) { return a ? `${a.slice(0,6)}...${a.slice(-4)}` : '' }

// small Logo
function Logo() { return (
// inline svg
  <svg width="44" height="44" viewBox="0 0 80 80" xmlns="http://www.w3.org/2000/svg">
    <rect width="80" height="80" rx="16" fill="url(#g)"/>
    <path d="M20 55 L40 20 L60 55 Z" fill="white" opacity="0.95" />
    <defs><linearGradient id="g" x1="0" x2="1"><stop offset="0" stopColor="#FF6B6B" /><stop offset="1" stopColor="#7C5CFF" /></linearGradient></defs>
  </svg>
) }

export default function App() {
  const [provider, setProvider] = useState(null)
  const [signer, setSigner] = useState(null)
  const [account, setAccount] = useState(null)
  const [status, setStatus] = useState('')
  const [staked, setStaked] = useState([])
  const [myTokens, setMyTokens] = useState([])
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    if (window.ethereum) {
      window.ethereum.on && window.ethereum.on('accountsChanged', (accounts) => setAccount(accounts[0] || null))
      window.ethereum.on && window.ethereum.on('chainChanged', () => window.location.reload())
    }
  }, [])

  async function connect() {
    try {
      if (!window.ethereum) throw new Error('No web3 provider (MetaMask)')
      const prov = ethers.BrowserProvider ? new ethers.BrowserProvider(window.ethereum) : new ethers.providers.Web3Provider(window.ethereum, 'any')
      await (prov.send ? prov.send('eth_requestAccounts', []) : window.ethereum.request({ method: 'eth_requestAccounts' }))
      const s = prov.getSigner ? prov.getSigner() : prov.getSigner()
      const addr = await s.getAddress()
      setProvider(prov)
      setSigner(s)
      setAccount(addr)
      setStatus('Connected: ' + formatAddr(addr))
    } catch (err) { console.error(err); setStatus('Connect failed: ' + (err.message || err)) }
  }

  // Load staked tokens for account (reads from staking contract)
  async function loadStaked() {
    if (!provider || !account) return setStatus('Connect wallet first')
    try {
      setIsLoading(true)
      const staking = new ethers.Contract(CONFIG.STAKING_CONTRACT_ADDRESS, CONFIG.STAKING_ABI, provider)
      const list = await staking.stakedOf(account)
      const arr = Array.isArray(list) ? list.map(x => x.toString()) : []
      setStaked(arr)
      setStatus('Loaded staked tokens: ' + arr.length)
    } catch (err) { console.error(err); setStatus('Failed to load staked: ' + (err.message || err)) } finally { setIsLoading(false) }
  }

  async function addMyToken() { setMyTokens(prev => prev) }

  async function stake(tokenId) {
    if (!signer) return setStatus('Connect wallet first')
    try {
      setIsLoading(true)
      const staking = new ethers.Contract(CONFIG.STAKING_CONTRACT_ADDRESS, CONFIG.STAKING_ABI, signer)
      const tx = await staking.stake(tokenId)
      setStatus('Stake tx sent: ' + tx.hash)
      await tx.wait()
      setStatus('Staked ' + tokenId)
      loadStaked()
    } catch (err) { console.error(err); setStatus('Stake failed: ' + (err.message || err)) } finally { setIsLoading(false) }
  }

  async function unstake(tokenId) {
    if (!signer) return setStatus('Connect wallet first')
    try {
      setIsLoading(true)
      const staking = new ethers.Contract(CONFIG.STAKING_CONTRACT_ADDRESS, CONFIG.STAKING_ABI, signer)
      const tx = await staking.unstake(tokenId)
      setStatus('Unstake tx sent: ' + tx.hash)
      await tx.wait()
      setStatus('Unstaked ' + tokenId)
      loadStaked()
    } catch (err) { console.error(err); setStatus('Unstake failed: ' + (err.message || err)) } finally { setIsLoading(false) }
  }

  async function claim() {
    if (!signer) return setStatus('Connect wallet first')
    try {
      setIsLoading(true)
      const staking = new ethers.Contract(CONFIG.STAKING_CONTRACT_ADDRESS, CONFIG.STAKING_ABI, signer)
      const tx = await staking.claimRewards()
      setStatus('Claim tx sent: ' + tx.hash)
      await tx.wait()
      setStatus('Claim complete')
      loadStaked()
    } catch (err) { console.error(err); setStatus('Claim failed: ' + (err.message || err)) } finally { setIsLoading(false) }
  }

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-4xl mx-auto bg-slate-900 rounded-2xl p-6">
        <header className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3"><Logo /><div><div className="font-bold text-white">DAISUKI99</div><div className="text-sm text-slate-400">Polygon Mint & Staking (MATIC rewards)</div></div></div>
          <div>
            {account ? <div className="px-3 py-2 bg-slate-800 rounded">{formatAddr(account)}</div> : <button onClick={connect} className="px-4 py-2 bg-gradient-to-r from-[#7C5CFF] to-[#3DD1C7] rounded">Connect Wallet</button>}
          </div>
        </header>

        <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-slate-800 p-4 rounded">
            <h3 className="font-bold mb-2">Mint (NFT contract)</h3>
            <div className="text-sm mb-2">NFT contract: <code className="text-xs">{CONFIG.NFT_CONTRACT_ADDRESS}</code></div>
            <p className="text-sm text-slate-300">Mint UI not implemented in this build — use your existing mint page or Farcaster frame. This app focuses on staking & MATIC rewards.</p>
          </div>

          <div className="bg-slate-800 p-4 rounded">
            <h3 className="font-bold mb-2">Staking</h3>
            <div className="text-sm mb-2">Staking contract: <code className="text-xs">{CONFIG.STAKING_CONTRACT_ADDRESS}</code></div>
            <div className="flex gap-2">
              <button onClick={loadStaked} className="px-3 py-1 bg-slate-700 rounded">Load my staked</button>
              <button onClick={claim} className="px-3 py-1 bg-amber-600 rounded">Claim MATIC</button>
            </div>
          </div>
        </section>

        <section className="mt-6 bg-slate-800 p-4 rounded">
          <h4 className="font-bold mb-2">My staked tokens</h4>
          <div className="flex flex-wrap gap-2">
            {staked.length === 0 ? <div className="text-slate-400">No staked tokens or not loaded yet.</div> : staked.map(t => (
              <div key={t} className="bg-slate-700 p-3 rounded flex items-center gap-2"><div className="font-mono">#{t}</div><button onClick={() => unstake(t)} className="px-2 py-1 bg-red-600 rounded text-sm">Unstake</button></div>
            ))}
          </div>
        </section>

        <div className="mt-4 text-sm text-slate-400">Status: {status}</div>

        <footer className="mt-6 text-xs text-slate-500">Notes: Rewards are paid in MATIC by the staking contract. Deploy the included Staking.sol to Polygon (Mumbai for testing or Polygon mainnet) and fund it with MATIC to pay rewards.</footer>
      </div>
    </div>
  )
}
