# Daisuki Mint & Staking (v2) - Polygon MATIC rewards

This package contains a frontend (Vite + React + Tailwind) and a simple staking contract
that pays rewards in MATIC (native). You gave NFT contract: 0x5676fCF549f434D0D1E71baD9370cdb451968109

## Quickstart (frontend)
1. Unzip and install:
   ```bash
   npm install
   npm run dev
   ```
2. Update `src/App.jsx`:
   - Set `CONFIG.STAKING_CONTRACT_ADDRESS` to your deployed staking address.

## Deploy Staking contract (Hardhat)
1. Install dependencies (if not already):
   ```bash
   npm install
   ```
2. Set env variables in `.env`:
   - `PRIVATE_KEY` - deployer key (keep secret)
   - `MUMBAI_RPC` - your RPC URL for Mumbai (testnet)
   - `POLYGON_RPC` - RPC URL for Polygon mainnet (if deploying to mainnet)
   - `NFT_ADDRESS` - your NFT contract (pre-filled in frontend)
   - `REWARD_RATE_WEI` - reward amount in wei per second (optional)
3. Deploy to Mumbai (for testing):
   ```bash
   npx hardhat run --network mumbai scripts/deploy.js
   ```
4. Fund the deployed staking contract with MATIC so it can pay rewards:
   - Send MATIC from your wallet to the staking contract address.

## Notes
- Reward formula: `elapsed_seconds * rewardRate` (rewardRate is wei per second per NFT).
- This staking contract is intentionally simple. Audit before mainnet use.
